// config/database.js

module.exports = {
    'connection': {
        'host': 'localhost',
        // 'port': '3307',
        'user': 'root',
        'password': ''
    },
    'database': 'test_db',
    'users_table': 'users'
};

