const ConsultationRequest = require('../models/ConsultationRequest'); // Предполагам, че моделът вече е създаден
const User = require('../models/usersTableModel'); // Пътят до модела може да се различава
const UserProfile = require('../models/userModel');
const Lawyer = require('../models/lawyer'); // Модел за потребителя, предполага се, че вече е създаден
// Останалата част от кода...


const nodemailer = require('nodemailer');

UserProfile.hasMany(ConsultationRequest, { foreignKey: 'userId', as: 'consultations' });
ConsultationRequest.belongsTo(UserProfile, { foreignKey: 'userId', as: 'userModel' });

Lawyer.hasMany(ConsultationRequest, { foreignKey: 'lawyerId', as: 'consultations' });
ConsultationRequest.belongsTo(Lawyer, { foreignKey: 'lawyerId', as: 'lawyer' });


exports.getAllConsultations = async (req, res) => {
    try {
        const consultations = await ConsultationRequest.findAll({
            include: [
                { model: UserProfile, as: 'userModel' },  // Сигурни ли сте, че псевдонимът е 'user'?
                { model: Lawyer, as: 'lawyer' }
            ]
            
        });
        res.status(200).send(consultations);
    } catch (error) {
        res.status(400).send(error.message);
    }
};




// Маршрут




// Създаване на нова консултация
exports.createConsultation = async (req, res) => {
    try {
        
    
        const { userId, lawyerId, appointmentDateTime } = req.body;
        const newConsultation = await ConsultationRequest.create({
            userId,
            lawyerId,
            appointmentDateTime, // Актуализирано да използва новата колона
            status: 'pending' // Изходно състояние на заявката
        });
        res.status(201).send(newConsultation);
        
    } catch (error) {
        res.status(400).send(error.message);
    }
};

// Извличане на консултации за конкретен адвокат
exports.getConsultationsForLawyer = async (req, res) => {
    try {
        const { lawyerId } = req.params;
        const consultations = await ConsultationRequest.findAll({
            where: { lawyerId } 
        });
        res.status(200).send(consultations);
    } catch (error) {
        res.status(400).send(error.message);
    }
};

// Обновяване на консултация
exports.updateConsultation = async (req, res) => {
    try {
        const { consultationId } = req.params;
        const { status } = req.body;
        const consultation = await ConsultationRequest.findByPk(consultationId);

        if (!consultation) {
            return res.status(404).send("Consultation not found.");
        }

        consultation.status = status;
        await consultation.save();

        res.status(200).send(consultation);
    } catch (error) {
        res.status(400).send(error.message);
    }
};


// Одобряване на консултация
exports.approveConsultation = async (req, res) => {
    try {
        const { consultationId } = req.params;
        const consultation = await ConsultationRequest.findByPk(consultationId);

        if (!consultation) {
            return res.status(404).send({ message: "Consultation not found." });
        }

        consultation.status = 'approved';
        await consultation.save();

        res.status(200).send({ message: "Consultation approved successfully." });
    } catch (error) {
        res.status(400).send(error.message);
    }
};

// Отхвърляне на консултация
exports.declineConsultation = async (req, res) => {
    try {
        const { consultationId } = req.params;
        const consultation = await ConsultationRequest.findByPk(consultationId);

        if (!consultation) {
            return res.status(404).send({ message: "Consultation not found." });
        }

        consultation.status = 'declined';
        await consultation.save();

        res.status(200).send({ message: "Consultation declined successfully." });
    } catch (error) {
        res.status(400).send(error.message);
    }
};
