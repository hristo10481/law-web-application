const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/db'); 

class ConsultationRequest extends Model {}

ConsultationRequest.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  userId: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
    references: {
      model: 'UserProfile',
      tableName: 'profiles',
      key: 'id',
    }
  },
  lawyerId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'lawyers',
      tableName: 'lawyers',
      key: 'id',
    }
  },
  appointmentDateTime: {
    type: DataTypes.DATE,
    allowNull: true
  },
  status: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: 'pending' // Предполагаме, че всяка нова заявка за консултация е в състояние "в очакване"
  }
}, {
  sequelize,
  modelName: 'ConsultationRequest',
  tableName: 'consultationrequest',
  timestamps: false
});

module.exports = ConsultationRequest;
